# Catálogo · Electrolux San Pedro

Catálogo web con tu marca que muestra productos de shopclub **sin precios** y
se **actualiza solo una vez al día** con el stock e imágenes de la tienda.

## Qué hay aquí

- **index.html** — el catálogo (tu marca, filtros, búsqueda, botón de WhatsApp).
- **sync.js** — recorre shopclub y genera `productos.json` (nombre, marca, categoría, disponibilidad e imágenes).
- **.github/workflows/sync.yml** — corre `sync.js` una vez al día, solo.
- **productos.json** — lo genera el script; es lo que muestra el catálogo.

## Antes de publicar (2 minutos)

1. Abre **index.html** y en la constante `CONFIG` (cerca del final) pon:
   - `nombre`: el nombre de tu tienda
   - `tagline`: la bajada corta
   - `whatsapp`: tu número (ya está el +56 9 5096 9574)
   - los textos del `heroTitulo` / `heroTexto` si quieres
2. El **color de tu marca** se cambia arriba del archivo, en `--accent`.
3. En **sync.js**, la lista `MARCAS` ya trae Electrolux, Fensa y Mademsa. Déjala vacía `[]` si quieres traer todas.

## Probar en tu computador (opcional)

Con Node 18 o superior instalado:

```bash
node sync.js        # genera productos.json
```

Luego abre index.html en el navegador. (Nota: al abrirlo como archivo local,
si el navegador bloquea la lectura de `productos.json` verás los productos de
ejemplo; publicado en internet funciona sin problema.)

## Publicar gratis con tu dominio .cl

1. Crea un repositorio en GitHub y sube estos archivos.
2. En **Settings → Pages**, elige la rama `main` y carpeta `/ (root)`. GitHub te da una URL pública.
3. En **Settings → Pages → Custom domain**, escribe tu dominio .cl y sigue los pasos de DNS que te indica.
4. Ve a la pestaña **Actions**, elige *Actualizar catálogo* y haz clic en **Run workflow** para la primera carga. Desde ahí en adelante se actualiza solo cada día.

## Ajustes rápidos

- **Hora de actualización:** en `sync.yml`, la línea `cron`.
- **Tamaño de imágenes / cuántas por producto:** en `sync.js`, `IMG` y `MAX_IMAGENES`.
- **Disponibilidad:** el catálogo muestra *Disponible* o *Consultar*; la confirmación final es en tienda.
